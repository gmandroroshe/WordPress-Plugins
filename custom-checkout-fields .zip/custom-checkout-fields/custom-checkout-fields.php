<?php
/*
Plugin Name: Custom Checkout Fields
Description: Adds custom date and time fields to the WooCommerce checkout page.
Version: 1.0
Author: Kavindu Maduranga
*/

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Add date and time fields to the checkout page
add_action('woocommerce_after_order_notes', 'ccf_add_custom_checkout_fields');

function ccf_add_custom_checkout_fields($checkout) {
    echo '<div id="ccf_custom_checkout_field"><h3>' . __('Preferred Delivery Date & Time') . '</h3>';

    woocommerce_form_field('ccf_delivery_date', array(
        'type' => 'date',
        'class' => array('form-row-wide'),
        'label' => __('Delivery Date'),
        'placeholder' => __('Select a date'),
    ), $checkout->get_value('ccf_delivery_date'));

    woocommerce_form_field('ccf_delivery_time', array(
        'type' => 'time',
        'class' => array('form-row-wide'),
        'label' => __('Delivery Time'),
        'placeholder' => __('Select a time'),
    ), $checkout->get_value('ccf_delivery_time'));

    echo '</div>';
}

// Validate the custom fields
add_action('woocommerce_checkout_process', 'ccf_custom_checkout_field_process');
function ccf_custom_checkout_field_process() {
    if (!$_POST['ccf_delivery_date']) {
        wc_add_notice(__('Please enter a delivery date.'), 'error');
    }
    if (!$_POST['ccf_delivery_time']) {
        wc_add_notice(__('Please enter a delivery time.'), 'error');
    }
}

// Save the custom fields
add_action('woocommerce_checkout_update_order_meta', 'ccf_custom_checkout_field_update_order_meta');
function ccf_custom_checkout_field_update_order_meta($order_id) {
    if (!empty($_POST['ccf_delivery_date'])) {
        update_post_meta($order_id, 'ccf_delivery_date', sanitize_text_field($_POST['ccf_delivery_date']));
    }
    if (!empty($_POST['ccf_delivery_time'])) {
        update_post_meta($order_id, 'ccf_delivery_time', sanitize_text_field($_POST['ccf_delivery_time']));
    }
}

// Display the custom fields in the order admin panel
add_action('woocommerce_admin_order_data_after_billing_address', 'ccf_custom_checkout_field_display_admin_order_meta', 10, 1);
function ccf_custom_checkout_field_display_admin_order_meta($order) {
    echo '<p><strong>' . __('Delivery Date') . ':</strong> ' . get_post_meta($order->get_id(), 'ccf_delivery_date', true) . '</p>';
    echo '<p><strong>' . __('Delivery Time') . ':</strong> ' . get_post_meta($order->get_id(), 'ccf_delivery_time', true) . '</p>';
}
?>
