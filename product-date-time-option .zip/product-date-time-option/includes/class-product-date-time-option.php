<?php

class Product_Date_Time_Option {

    public function __construct() {
        // Hook to display custom fields on the product page.
        add_action('woocommerce_before_add_to_cart_button', [$this, 'display_date_time_fields']);
        
        // Hook to add custom fields data to the cart item.
        add_filter('woocommerce_add_cart_item_data', [$this, 'add_date_time_to_cart_item'], 10, 2);
        
        // Hook to display custom fields data in the cart.
        add_filter('woocommerce_get_item_data', [$this, 'display_date_time_in_cart'], 10, 2);
        
        // Hook to save custom fields data to the order items.
        add_action('woocommerce_checkout_create_order_line_item', [$this, 'save_date_time_to_order_items'], 10, 4);
    }

    public function run() {
        // Hook into WooCommerce to add custom functionality.
    }

    // Display date and time fields on the product page.
    public function display_date_time_fields() {
        echo '<div class="product-date-time-option">';
        echo '<label for="product_date">Select Date:</label>';
        echo '<input type="date" id="product_date" name="product_date">';
        echo '<label for="product_time">Select Time:</label>';
        echo '<input type="time" id="product_time" name="product_time">';
        echo '</div>';
    }

    // Add date and time data to the cart item.
    public function add_date_time_to_cart_item($cart_item_data, $product_id) {
        if (isset($_POST['product_date'])) {
            $cart_item_data['product_date'] = sanitize_text_field($_POST['product_date']);
        }
        if (isset($_POST['product_time'])) {
            $cart_item_data['product_time'] = sanitize_text_field($_POST['product_time']);
        }
        return $cart_item_data;
    }

    // Display date and time data in the cart.
    public function display_date_time_in_cart($item_data, $cart_item) {
        if (isset($cart_item['product_date'])) {
            $item_data[] = array(
                'key' => __('Date', 'woocommerce'),
                'value' => wc_clean($cart_item['product_date']),
            );
        }
        if (isset($cart_item['product_time'])) {
            $item_data[] = array(
                'key' => __('Time', 'woocommerce'),
                'value' => wc_clean($cart_item['product_time']),
            );
        }
        return $item_data;
    }

    // Save date and time data to order items.
    public function save_date_time_to_order_items($item, $cart_item_key, $values, $order) {
        if (isset($values['product_date'])) {
            $item->add_meta_data(__('Date', 'woocommerce'), $values['product_date'], true);
        }
        if (isset($values['product_time'])) {
            $item->add_meta_data(__('Time', 'woocommerce'), $values['product_time'], true);
        }
    }
}
