<?php
/*
Plugin Name: Product Date Time Option
Description: Adds a date and time option to WooCommerce products.
Version: 1.0
Author: Kavindu Maduranga
*/

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

// Include the main plugin class.
require_once(plugin_dir_path(__FILE__) . 'includes/class-product-date-time-option.php');

// Initialize the plugin.
function run_product_date_time_option() {
    $plugin = new Product_Date_Time_Option();
    $plugin->run();
}
run_product_date_time_option();
