<?php
/*
Plugin Name: Radio Textbox Plugin for WooCommerce
Plugin URI: http://example.com/radio-textbox-plugin
Description: A plugin that shows a text box when a radio button is selected on WooCommerce product pages.
Version: 1.0
Author: Your Name
Author URI: http://example.com
License: GPL2
*/

// Enqueue scripts and styles
function rtp_enqueue_scripts() {
    if (is_product()) {
        wp_enqueue_script('rtp-script', plugin_dir_url(__FILE__) . 'js/rtp-script.js', array('jquery'), null, true);
        wp_enqueue_style('rtp-style', plugin_dir_url(__FILE__) . 'css/rtp-style.css');
    }
}
add_action('wp_enqueue_scripts', 'rtp_enqueue_scripts');

// Display form on WooCommerce product pages
function rtp_display_form() {
    $heading_text = get_option('rtp_heading_text', 'Choose an option');
    ?>
    <div class="rtp-custom-form">
        <h3><?php echo esc_html($heading_text); ?></h3>
        <label>
            <input type="radio" name="rtp-radio" value="yes"> Yes
        </label>
        <label>
            <input type="radio" name="rtp-radio" value="no"> No
        </label>
        <div id="rtp-textbox">
            <input type="text" name="rtp-name" placeholder="Enter your name">
        </div>
    </div>
    <?php
}
add_action('woocommerce_after_add_to_cart_button', 'rtp_display_form');

// Create settings page
function rtp_create_settings_page() {
    add_options_page(
        'Radio Textbox Settings',
        'Radio Textbox Settings',
        'manage_options',
        'rtp-settings',
        'rtp_settings_page_html'
    );
}
add_action('admin_menu', 'rtp_create_settings_page');

// Register settings
function rtp_register_settings() {
    register_setting('rtp_settings_group', 'rtp_heading_text');
}
add_action('admin_init', 'rtp_register_settings');

// Settings page HTML
function rtp_settings_page_html() {
    ?>
    <div class="wrap">
        <h1>Radio Textbox Settings</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('rtp_settings_group');
            do_settings_sections('rtp_settings_group');
            ?>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">Heading Text</th>
                    <td><input type="text" name="rtp_heading_text" value="<?php echo esc_attr(get_option('rtp_heading_text', 'Choose an option')); ?>" /></td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}
