jQuery(document).ready(function($) {
    $('input[name="rtp-radio"]').change(function() {
        if ($(this).val() == 'yes') {
            $('#rtp-textbox').show();
        } else {
            $('#rtp-textbox').hide();
        }
    });
});
