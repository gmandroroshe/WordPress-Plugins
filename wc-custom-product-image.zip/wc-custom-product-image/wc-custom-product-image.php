<?php
/*
Plugin Name: WooCommerce Custom Product Image
Description: Allows customers to upload a custom image for WooCommerce products.
Version: 1.0
Author: Your Name
*/

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

// Include the main class file
require_once plugin_dir_path( __FILE__ ) . 'includes/class-wc-custom-product-image.php';

function wc_custom_product_image_init() {
    $wc_custom_product_image = new WC_Custom_Product_Image();
}
add_action( 'plugins_loaded', 'wc_custom_product_image_init' );
?>
