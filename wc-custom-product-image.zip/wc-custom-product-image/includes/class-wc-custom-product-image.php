<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

class WC_Custom_Product_Image {

    public function __construct() {
        add_action( 'woocommerce_before_add_to_cart_button', array( $this, 'add_custom_image_field' ) );
        add_filter( 'woocommerce_add_cart_item_data', array( $this, 'save_custom_image_data' ), 10, 2 );
        add_filter( 'woocommerce_get_cart_item_from_session', array( $this, 'get_cart_item_custom_image_data' ), 10, 2 );
        add_action( 'woocommerce_checkout_create_order_line_item', array( $this, 'add_custom_image_to_order_items' ), 10, 4 );
        add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
    }

    public function enqueue_scripts() {
        wp_enqueue_script( 'wc-custom-product-image-public', plugin_dir_url( __FILE__ ) . '../public/public-scripts.js', array('jquery'), '1.0', true );
        wp_enqueue_style( 'wc-custom-product-image-styles', plugin_dir_url( __FILE__ ) . '../css/styles.css' );
    }

    public function add_custom_image_field() {
        echo '<div class="custom-product-image"><label for="custom_product_image">' . __( 'Upload your custom image', 'woocommerce' ) . '</label>';
        echo '<input type="file" id="custom_product_image" name="custom_product_image" accept="image/*" /></div>';
    }

    public function save_custom_image_data( $cart_item_data, $product_id ) {
        if ( isset( $_FILES['custom_product_image'] ) && !empty( $_FILES['custom_product_image']['name'] ) ) {
            $upload = wp_handle_upload( $_FILES['custom_product_image'], array( 'test_form' => false ) );
            if ( !isset( $upload['error'] ) && isset( $upload['url'] ) ) {
                $cart_item_data['custom_product_image'] = $upload['url'];
            }
        }
        return $cart_item_data;
    }

    public function get_cart_item_custom_image_data( $cart_item, $values ) {
        if ( isset( $values['custom_product_image'] ) ) {
            $cart_item['custom_product_image'] = $values['custom_product_image'];
        }
        return $cart_item;
    }

    public function add_custom_image_to_order_items( $item, $cart_item_key, $values, $order ) {
        if ( isset( $values['custom_product_image'] ) ) {
            $item->add_meta_data( __( 'Custom Image', 'woocommerce' ), $values['custom_product_image'], true );
        }
    }
}
?>
