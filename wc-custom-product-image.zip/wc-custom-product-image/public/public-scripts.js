jQuery(document).ready(function($) {
    $('#custom_product_image').change(function(e) {
        var fileName = e.target.files[0].name;
        alert('The file "' + fileName + '" has been selected.');
    });
});
