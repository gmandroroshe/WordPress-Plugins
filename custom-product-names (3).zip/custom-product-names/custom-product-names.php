<?php
/*
Plugin Name: Custom Product Names
Description: Add custom name inputs to WooCommerce products with dynamic price adjustment.
Version: 1.1
Author: Your Name
*/

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Enqueue custom script and styles
function cpn_enqueue_custom_script() {
    if (is_product()) {
        wp_enqueue_script('cpn-custom-script', plugin_dir_url(__FILE__) . 'js/custom-product-names.js', array('jquery'), null, true);
        wp_enqueue_style('cpn-custom-style', plugin_dir_url(__FILE__) . 'css/custom-product-names.css');
        wp_localize_script('cpn-custom-script', 'cpn_params', array(
            'price_increment' => get_option('cpn_price_increment', 5),
            'heading_title' => get_option('cpn_heading_title', 'Would you like to add a custom name?')
        ));
    }
}
add_action('wp_enqueue_scripts', 'cpn_enqueue_custom_script');

// Display custom fields on the product page
function cpn_display_custom_fields() {
    $heading_title = get_option('cpn_heading_title', 'Would you like to add a custom name?');
    ?>
    <div>
        <h3><?php echo esc_html($heading_title); ?></h3>
        <label><input type="radio" name="add_name_option" value="yes"> Yes</label>
        <label><input type="radio" name="add_name_option" value="no" checked> No</label>
    </div>
    <div id="name-input-container" style="display:none;">
        <input type="text" class="additional-name" name="additional-names[]" placeholder="Enter name" />
    </div>
    <button id="add-more-names-button" style="display:none;">Add more names</button>
    <?php
}
add_action('woocommerce_before_add_to_cart_button', 'cpn_display_custom_fields');

// Process the custom fields and add to cart item data
function cpn_add_custom_field_item_data($cart_item_data, $product_id, $variation_id) {
    if (isset($_POST['additional-names'])) {
        $cart_item_data['additional_names'] = array_filter($_POST['additional-names']);
        $price_increment = get_option('cpn_price_increment', 5);
        $new_price = count($cart_item_data['additional_names']) * $price_increment;
        $cart_item_data['new_price'] = $new_price;
    }
    return $cart_item_data;
}
add_filter('woocommerce_add_cart_item_data', 'cpn_add_custom_field_item_data', 10, 3);

// Display custom fields in the cart
function cpn_display_custom_item_data($item_data, $cart_item) {
    if (isset($cart_item['additional_names'])) {
        $item_data[] = array(
            'key' => 'Additional Names',
            'value' => implode(', ', $cart_item['additional_names'])
        );
    }
    return $item_data;
}
add_filter('woocommerce_get_item_data', 'cpn_display_custom_item_data', 10, 2);

// Adjust the cart item price
function cpn_calculate_custom_price($cart_object) {
    foreach ($cart_object->get_cart() as $cart_item_key => $cart_item) {
        if (isset($cart_item['new_price'])) {
            $cart_item['data']->set_price($cart_item['data']->get_price() + $cart_item['new_price']);
        }
    }
}
add_action('woocommerce_before_calculate_totals', 'cpn_calculate_custom_price');

// Save custom fields to order
function cpn_save_custom_fields_to_order($item, $cart_item_key, $values, $order) {
    if (isset($values['additional_names'])) {
        $item->add_meta_data('Additional Names', implode(', ', $values['additional_names']));
    }
}
add_action('woocommerce_checkout_create_order_line_item', 'cpn_save_custom_fields_to_order', 10, 4);

// Create settings page
function cpn_create_settings_page() {
    add_options_page(
        'Custom Product Names Settings',
        'Custom Product Names',
        'manage_options',
        'custom-product-names',
        'cpn_settings_page_content'
    );
}
add_action('admin_menu', 'cpn_create_settings_page');

// Display settings page content
function cpn_settings_page_content() {
    ?>
    <div class="wrap">
        <h1>Custom Product Names Settings</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('cpn_settings_group');
            do_settings_sections('custom-product-names');
            submit_button();
            ?>
        </form>
    </div>
    <?php
}

// Register settings
function cpn_register_settings() {
    register_setting('cpn_settings_group', 'cpn_price_increment');
    register_setting('cpn_settings_group', 'cpn_heading_title');

    add_settings_section(
        'cpn_settings_section',
        'Price Increment Settings',
        'cpn_settings_section_callback',
        'custom-product-names'
    );

    add_settings_field(
        'cpn_price_increment',
        'Price Increment',
        'cpn_price_increment_callback',
        'custom-product-names',
        'cpn_settings_section'
    );

    add_settings_field(
        'cpn_heading_title',
        'Heading Title',
        'cpn_heading_title_callback',
        'custom-product-names',
        'cpn_settings_section'
    );
}
add_action('admin_init', 'cpn_register_settings');

// Settings section callback
function cpn_settings_section_callback() {
    echo 'Set the price increment for each additional name added.';
}

// Settings field callback for price increment
function cpn_price_increment_callback() {
    $price_increment = get_option('cpn_price_increment', 5);
    echo '<input type="number" name="cpn_price_increment" value="' . esc_attr($price_increment) . '" />';
}

// Settings field callback for heading title
function cpn_heading_title_callback() {
    $heading_title = get_option('cpn_heading_title', 'Would you like to add a custom name?');
    echo '<input type="text" name="cpn_heading_title" value="' . esc_attr($heading_title) . '" />';
}
