jQuery(document).ready(function($) {
    var namePriceIncrement = parseFloat(cpn_params.price_increment); // Get the price increment from PHP

    $('input[name="add_name_option"]').change(function() {
        if ($(this).val() === 'yes') {
            $('#name-input-container').show();
            $('#add-more-names-button').show();
        } else {
            $('#name-input-container').hide();
            $('#add-more-names-button').hide();
            $('#name-input-container').find('.additional-name').remove();
            updatePrice();
        }
    });

    $('#add-more-names-button').click(function(e) {
        e.preventDefault();
        $('#name-input-container').append('<input type="text" class="additional-name" name="additional-names[]" placeholder="Enter name"/>');
        updatePrice();
    });

    $('#name-input-container').on('input', '.additional-name', function() {
        updatePrice();
    });

    function updatePrice() {
        var additionalNamesCount = $('#name-input-container').find('.additional-name').length;
        var newPrice = additionalNamesCount * namePriceIncrement;
        var basePrice = parseFloat($('.woocommerce-Price-amount.amount').text().replace(/[^\d.]/g, ''));
        $('.woocommerce-Price-amount.amount').text('$' + (basePrice + newPrice).toFixed(2));
    }
});
